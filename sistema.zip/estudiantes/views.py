from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.http import HttpResponse
from django.utils import timezone
from datetime import timedelta
from django.core.paginator import Paginator
from django.contrib import messages
from django.contrib.auth import logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.models import User, Group
from django.core.mail import send_mail
from django.db.models import Q, Count, Max
from django.conf import settings
import io, csv, zipfile, json, os
from datetime import datetime
from decimal import Decimal, InvalidOperation
from urllib.parse import urlencode
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from .models import Estudiante, Asistencia, DocentePerfil, RegistroPlanilla, Actividad, NotaActividad
from .forms import EstudianteForm, UsuarioCrearForm, UsuarioEditarForm


# ── Decoradores de rol ──────────────────────────────────────

def solo_directivo(view_func):
    """Bloquea el acceso a usuarios que no sean directivos ni superusuarios."""
    def wrapper(request, *args, **kwargs):
        if not _es_directivo(request.user):
            messages.error(request, "No tiene permisos para acceder a esta sección.")
            return redirect('inicio')
        return view_func(request, *args, **kwargs)
    wrapper.__name__ = view_func.__name__
    return wrapper


def _es_directivo(user):
    return user.is_superuser or user.groups.filter(name='directivo').exists()


def _es_docente(user):
    return user.groups.filter(name='docente').exists()


def _es_estudiante(user):
    """True si la cuenta corresponde a un estudiante (tiene ficha vinculada)."""
    return hasattr(user, 'estudiante_perfil')


def bloquear_estudiantes(view_func):
    """Impide que las cuentas de estudiante accedan a las vistas internas del sistema."""
    def wrapper(request, *args, **kwargs):
        if _es_estudiante(request.user):
            return redirect('mi_historial')
        return view_func(request, *args, **kwargs)
    wrapper.__name__ = view_func.__name__
    return wrapper


def _grupo_docente(user):
    """Devuelve (linea, jornada) asignada al docente, o None."""
    perfil = getattr(user, 'docente_perfil', None)
    if perfil:
        return (perfil.linea, perfil.jornada)
    return None


def _puede_usar_planilla(user):
    return _es_directivo(user) or _grupo_docente(user) is not None


def _asegurar_grupos():
    """Crea los grupos Docente, Directivo y Estudiante si no existen."""
    Group.objects.get_or_create(name='docente')
    Group.objects.get_or_create(name='directivo')
    Group.objects.get_or_create(name='estudiante')


# ── Email helpers ───────────────────────────────────────────

def _enviar_bienvenida(user, password_plano, rol):
    rol_label = 'Directivo' if rol == 'directivo' else 'Docente'
    permisos  = ('Acceso completo al sistema.' if rol == 'directivo'
                 else 'Puede ver y buscar estudiantes. No puede editar ni eliminar.')
    try:
        send_mail(
            subject='Bienvenido al Sistema Escolar — Sus credenciales',
            message=(
                f"Hola {user.get_full_name() or user.username},\n\n"
                f"Se ha creado su cuenta en el Sistema de Gestión Escolar.\n\n"
                f"Usuario:     {user.username}\n"
                f"Contraseña:  {password_plano}\n"
                f"Rol:         {rol_label}\n"
                f"Permisos:    {permisos}\n\n"
                f"Por seguridad, cambie su contraseña después de iniciar sesión.\n"
                f"Para restablecer su contraseña, use la opción '¿Olvidó su contraseña?' en la página de inicio de sesión.\n\n"
                f"Sistema Escolar"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[user.email],
            fail_silently=False,
        )
        return True
    except Exception as e:
        return str(e)


# ── Helpers comunes ──────────────────────────────────────────

CAMPOS_EXPORTAR = [
    ('documento',           'Documento'),
    ('tipo',                'Tipo Doc.'),
    ('apellidos',           'Apellidos'),
    ('nombres',             'Nombres'),
    ('jornada',             'Jornada'),
    ('curso',               'Curso'),
    ('linea',               'Linea'),
    ('celular',             'Celular'),
    ('email',               'Email'),
    ('acudiente',           'Acudiente'),
    ('parentesco',          'Parentesco'),
    ('tel_acudiente',       'Tel. Acudiente'),
    ('tel2_acudiente',      'Tel. Acudiente 2'),
    ('direccion',           'Direccion'),
    ('ocupacion_acudiente', 'Ocupacion Acudiente'),
    ('eps',                 'EPS'),
    ('observaciones',       'Observaciones'),
    ('archivo_foto',        'Archivo Foto'),
]
CAMPOS_IMPORTAR_REQUERIDOS = ['documento', 'apellidos', 'nombres', 'jornada', 'curso', 'linea']
VALORES_JORNADA = [v for v, _ in Estudiante.JORNADA]
VALORES_LINEA   = [v for v, _ in Estudiante.LINEA_MEDIA]
VALORES_TIPO    = [v for v, _ in Estudiante.TIPOS_DOCUMENTO]


def _qs_filtrada(get):
    qs = Estudiante.objects.all().order_by('apellidos', 'nombres')
    q       = get.get('q', '').strip()
    jornadas = [j for j in get.getlist('jornada') if j]
    grados   = [g for g in get.getlist('grado')   if g]
    lineas   = [l for l in get.getlist('linea')   if l]
    cursos   = [c for c in get.getlist('curso')   if c]
    if q:
        qs = qs.filter(Q(nombres__icontains=q) | Q(apellidos__icontains=q) | Q(documento__icontains=q))
    if jornadas:
        qs = qs.filter(jornada__in=jornadas)
    if grados:
        q_grado = Q()
        for g in grados:
            q_grado |= Q(curso__startswith=g)
        qs = qs.filter(q_grado)
    if lineas:
        qs = qs.filter(linea__in=lineas)
    if cursos:
        qs = qs.filter(curso__in=cursos)
    return qs


def _build_excel(queryset):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Estudiantes"
    hf = PatternFill("solid", fgColor="1a3a6e")
    hfont = Font(color="FFFFFF", bold=True, size=11)
    halign = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin = Side(style="thin", color="D1D5DB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for col_idx, (_, label) in enumerate(CAMPOS_EXPORTAR, 1):
        c = ws.cell(row=1, column=col_idx, value=label)
        c.fill = hf; c.font = hfont; c.alignment = halign; c.border = border
    ws.row_dimensions[1].height = 28
    alt = PatternFill("solid", fgColor="F8FAFC")
    for ri, est in enumerate(queryset, 2):
        for ci, (field, _) in enumerate(CAMPOS_EXPORTAR, 1):
            if field == 'archivo_foto':
                val = os.path.basename(est.foto.name) if est.foto else ''
            else:
                val = getattr(est, field, '') or ''
            c = ws.cell(row=ri, column=ci, value=str(val))
            c.alignment = Alignment(vertical="center"); c.border = border
            if ri % 2 == 0: c.fill = alt
    anchos = [14,8,20,20,10,8,10,14,24,22,12,14,14,24,20,14,30,20]
    for i, w in enumerate(anchos, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    return buf


def _leer_excel(archivo):
    try:
        wb = openpyxl.load_workbook(archivo, data_only=True)
    except Exception as e:
        return None, [f"No se pudo leer el archivo: {e}"]
    ws = wb.active
    headers = [str(ws.cell(1, c).value).strip() if ws.cell(1, c).value else '' for c in range(1, ws.max_column + 1)]
    label_to_field = {label: field for field, label in CAMPOS_EXPORTAR}
    col_map = {i: label_to_field[h] for i, h in enumerate(headers) if h in label_to_field}
    if 'documento' not in col_map.values():
        return None, ["El archivo no tiene columna 'Documento'. Use la plantilla descargada."]
    filas = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        if all(v is None for v in row): continue
        fila = {field: (str(row[i]).strip() if i < len(row) and row[i] is not None else '')
                for i, field in col_map.items()}
        filas.append(fila)
    return filas, []


# ── Vistas generales ────────────────────────────────────────

@login_required
def inicio(request):
    contexto = {
        'es_directivo':  _es_directivo(request.user),
        'es_estudiante': _es_estudiante(request.user),
    }
    if contexto['es_estudiante']:
        estudiante = request.user.estudiante_perfil
        anio = timezone.now().year
        contexto['estudiante'] = estudiante
        contexto['anio'] = anio
        contexto['conteos'] = {
            tipo: Asistencia.objects.filter(estudiante=estudiante, tipo=tipo, fecha__year=anio).count()
            for tipo in ('ALM', 'TAR', 'UNI', 'ASI')
        }
    return render(request, 'paginas/inicio.html', contexto)

@login_required
@bloquear_estudiantes
def nosotros(request):
    return render(request, 'paginas/nosotros.html')


# ── Estudiantes ──────────────────────────────────────────────

@login_required
@bloquear_estudiantes
def estudiantes(request):
    qs = _qs_filtrada(request.GET)
    paginator = Paginator(qs, 25)
    page_obj  = paginator.get_page(request.GET.get('page', 1))
    cursos_disponibles = Estudiante.objects.values_list('curso', flat=True).distinct().order_by('curso')
    return render(request, 'estudiantes/index.html', {
        'page_obj':           page_obj,
        'total_filtrado':     qs.count(),
        'total_general':      Estudiante.objects.count(),
        'cursos_disponibles': cursos_disponibles,
        'jornadas':           Estudiante.JORNADA,
        'lineas':             Estudiante.LINEA_MEDIA,
        'filtro_q':        request.GET.get('q', ''),
        'filtro_jornadas': request.GET.getlist('jornada'),
        'filtro_grados':   request.GET.getlist('grado'),
        'filtro_lineas':   request.GET.getlist('linea'),
        'hay_filtros':     bool(request.GET.get('q') or any(request.GET.getlist('jornada')) or
                               any(request.GET.getlist('grado')) or any(request.GET.getlist('linea'))),
        'es_directivo':   _es_directivo(request.user),
    })


@login_required
@solo_directivo
def crear(request):
    formulario = EstudianteForm(request.POST or None, request.FILES or None)
    if formulario.is_valid():
        formulario.save()
        messages.success(request, "Estudiante creado correctamente.")
        return redirect('estudiantes')
    return render(request, 'estudiantes/crear.html', {'formulario': formulario})


@login_required
@solo_directivo
def editar(request, id):
    estudiante = get_object_or_404(Estudiante, id=id)
    formulario = EstudianteForm(request.POST or None, request.FILES or None, instance=estudiante)
    if formulario.is_valid():
        formulario.save()
        messages.success(request, "Estudiante actualizado correctamente.")
        return redirect('estudiantes')
    return render(request, 'estudiantes/editar.html', {'formulario': formulario})


@login_required
@solo_directivo
def eliminar(request, id):
    get_object_or_404(Estudiante, id=id).delete()
    messages.success(request, "Estudiante eliminado.")
    return redirect('estudiantes')


@login_required
@bloquear_estudiantes
def detalle(request, id):
    estudiante = get_object_or_404(Estudiante, id=id)
    anio = timezone.now().year
    conteos = {
        tipo: Asistencia.objects.filter(estudiante=estudiante, tipo=tipo, fecha__year=anio).count()
        for tipo in ('ALM', 'TAR', 'UNI', 'ASI')
    }
    return render(request, 'estudiantes/detalle.html', {
        'estudiante':   estudiante,
        'es_directivo': _es_directivo(request.user),
        'conteos':      conteos,
        'anio':         anio,
    })


@login_required
def cambiar_clave_obligatorio(request):
    if not _es_estudiante(request.user):
        return redirect('inicio')

    estudiante = request.user.estudiante_perfil
    if not estudiante.debe_cambiar_clave:
        return redirect('mi_historial')

    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            estudiante.debe_cambiar_clave = False
            estudiante.save(update_fields=['debe_cambiar_clave'])
            update_session_auth_hash(request, user)  # no cerrar la sesión al cambiar la clave
            messages.success(request, "Contraseña actualizada. Ya puede continuar.")
            return redirect('mi_historial')
    else:
        form = PasswordChangeForm(request.user)

    for campo in form.fields.values():
        campo.widget.attrs['class'] = 'form-control'

    return render(request, 'estudiantes/cambiar_clave.html', {'form': form})


# ── Historial del estudiante (cuenta individual) ─────────────

@login_required
def mi_historial(request):
    if not _es_estudiante(request.user):
        messages.info(request, "Su cuenta no está asociada a una ficha de estudiante.")
        return redirect('inicio')

    estudiante = request.user.estudiante_perfil
    anio = timezone.now().year
    conteos = {
        tipo: Asistencia.objects.filter(estudiante=estudiante, tipo=tipo, fecha__year=anio).count()
        for tipo in ('ALM', 'TAR', 'UNI', 'ASI')
    }

    tipo_filtro = request.GET.get('tipo', '')
    qs = Asistencia.objects.filter(estudiante=estudiante).order_by('-fecha', '-hora')
    if tipo_filtro in dict(Asistencia.TIPO_REGISTRO):
        qs = qs.filter(tipo=tipo_filtro)

    paginator = Paginator(qs, 20)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    return render(request, 'estudiantes/mi_historial.html', {
        'estudiante':   estudiante,
        'conteos':      conteos,
        'anio':         anio,
        'page_obj':     page_obj,
        'tipo_filtro':  tipo_filtro,
        'tipos':        Asistencia.TIPO_REGISTRO,
    })


# ── Planilla de asistencia por grupo (docentes/directivos) ───

def _resolver_grupo(request):
    """Resuelve (es_directivo, linea, jornada, grado_filtro, grupos_disponibles, grados_disponibles,
    estudiantes_grupo) para las vistas de planilla y notas, a partir del docente o de los filtros GET/POST.
    El filtro es por línea, jornada y grado (10°/11°) — nunca por el código completo del curso."""
    es_directivo = _es_directivo(request.user)
    grupo_asignado = _grupo_docente(request.user)
    params = request.POST if request.method == 'POST' else request.GET

    linea = params.get('linea') or request.GET.get('linea') or (grupo_asignado[0] if grupo_asignado else '')
    jornada = params.get('jornada') or request.GET.get('jornada') or (grupo_asignado[1] if grupo_asignado else '')
    grado_filtro = params.get('grado') or request.GET.get('grado', '')

    if grupo_asignado and not es_directivo:
        linea, jornada = grupo_asignado

    grupos_disponibles = []
    if es_directivo:
        grupos_disponibles = list(
            Estudiante.objects.values_list('linea', 'jornada').distinct().order_by('linea', 'jornada')
        )

    estudiantes_grupo = Estudiante.objects.none()
    grados_disponibles = []
    if linea and jornada:
        estudiantes_grupo = Estudiante.objects.filter(linea=linea, jornada=jornada)
        grados_disponibles = sorted({
            c[:2] for c in estudiantes_grupo.exclude(curso='').values_list('curso', flat=True) if len(c) >= 2
        })
        if grado_filtro:
            estudiantes_grupo = estudiantes_grupo.filter(curso__startswith=grado_filtro)
        estudiantes_grupo = estudiantes_grupo.order_by('curso', 'apellidos', 'nombres')

    return es_directivo, linea, jornada, grado_filtro, grupos_disponibles, grados_disponibles, estudiantes_grupo


@login_required
@bloquear_estudiantes
def planilla_grupo(request):
    if not _puede_usar_planilla(request.user):
        messages.error(request, "Su cuenta no tiene una línea asignada para la planilla. Pida a un directivo que se la asigne.")
        return redirect('inicio')

    es_directivo, linea, jornada, grado_filtro, grupos_disponibles, grados_disponibles, estudiantes_grupo = _resolver_grupo(request)
    params = request.POST if request.method == 'POST' else request.GET

    hoy = timezone.localdate()
    try:
        fecha = datetime.strptime(params.get('fecha', ''), '%Y-%m-%d').date()
    except (ValueError, TypeError):
        fecha = hoy
    try:
        bloque = int(params.get('bloque', 1))
        if bloque not in (1, 2):
            bloque = 1
    except (TypeError, ValueError):
        bloque = 1

    registros_por_estudiante = {}
    resumen = {}

    if linea and jornada:
        if request.method == 'POST':
            estados_validos = set(dict(RegistroPlanilla.ESTADOS).keys())
            for est in estudiantes_grupo:
                seleccionados = set(request.POST.getlist(f'estado_{est.id}')) & estados_validos
                # Regla de exclusividad: la Falla inhabilita los demás ítems del bloque,
                # salvo la Excusa justificada, que la remedia.
                if 'F' in seleccionados:
                    seleccionados &= {'F', 'EX'}

                existentes = set(
                    RegistroPlanilla.objects.filter(estudiante=est, fecha=fecha, bloque=bloque)
                    .values_list('estado', flat=True)
                )
                for estado in seleccionados:
                    RegistroPlanilla.objects.update_or_create(
                        estudiante=est, fecha=fecha, bloque=bloque, estado=estado,
                        defaults={'registrado_por': request.user},
                    )
                for estado in existentes - seleccionados:
                    RegistroPlanilla.objects.filter(estudiante=est, fecha=fecha, bloque=bloque, estado=estado).delete()
            messages.success(request, f"Planilla guardada para {fecha.strftime('%d/%m/%Y')} — Bloque {bloque}.")
            qs = urlencode({'linea': linea, 'jornada': jornada, 'grado': grado_filtro, 'fecha': fecha.isoformat(), 'bloque': bloque})
            return redirect(f"{request.path}?{qs}")

        registros = RegistroPlanilla.objects.filter(estudiante__in=estudiantes_grupo, fecha=fecha, bloque=bloque)
        for r in registros:
            registros_por_estudiante.setdefault(r.estudiante_id, set()).add(r.estado)

        conteo_qs = (
            RegistroPlanilla.objects.filter(estudiante__in=estudiantes_grupo)
            .values('estudiante_id', 'estado').annotate(total=Count('id'))
        )
        for fila in conteo_qs:
            resumen.setdefault(fila['estudiante_id'], {})[fila['estado']] = fila['total']

        todos_los_registros = RegistroPlanilla.objects.filter(estudiante__in=estudiantes_grupo).values(
            'estudiante_id', 'fecha', 'bloque', 'estado'
        )
        puntos_por_estudiante = RegistroPlanilla.calcular_puntos_por_estudiante(todos_los_registros)
        for est in estudiantes_grupo:
            resumen.setdefault(est.id, {})['puntos'] = puntos_por_estudiante.get(est.id, 0)

    return render(request, 'estudiantes/planilla.html', {
        'es_directivo':       es_directivo,
        'grupos_disponibles': grupos_disponibles,
        'grados_disponibles': grados_disponibles,
        'linea': linea, 'jornada': jornada, 'grado_filtro': grado_filtro,
        'linea_display':   dict(Estudiante.LINEA_MEDIA).get(linea, linea),
        'jornada_display': dict(Estudiante.JORNADA).get(jornada, jornada),
        'fecha': fecha,
        'bloque': bloque,
        'estudiantes_grupo':         estudiantes_grupo,
        'registros_por_estudiante':  registros_por_estudiante,
        'resumen': resumen,
        'estados': RegistroPlanilla.ESTADOS,
        'puntos_config': RegistroPlanilla.obtener_puntos(),
    })


@login_required
@bloquear_estudiantes
def notas_grupo(request):
    if not _puede_usar_planilla(request.user):
        messages.error(request, "Su cuenta no tiene una línea asignada para calificar. Pida a un directivo que se la asigne.")
        return redirect('inicio')

    es_directivo, linea, jornada, grado_filtro, grupos_disponibles, grados_disponibles, estudiantes_grupo = _resolver_grupo(request)

    actividades = Actividad.objects.none()
    notas_grid = {}
    resumen = {}

    if linea and jornada:
        actividades = Actividad.objects.filter(linea=linea, jornada=jornada)

        if request.method == 'POST':
            if 'nueva_actividad' in request.POST:
                nombre = request.POST.get('nueva_actividad', '').strip()
                if nombre:
                    siguiente_orden = (actividades.aggregate(m=Max('orden'))['m'] or 0) + 1
                    Actividad.objects.create(linea=linea, jornada=jornada, nombre=nombre, orden=siguiente_orden, creado_por=request.user)
                    messages.success(request, f"Actividad '{nombre}' creada.")
                qs = urlencode({'linea': linea, 'jornada': jornada, 'grado': grado_filtro})
                return redirect(f"{request.path}?{qs}")

            elif 'eliminar_actividad' in request.POST:
                Actividad.objects.filter(id=request.POST.get('eliminar_actividad'), linea=linea, jornada=jornada).delete()
                messages.success(request, "Actividad eliminada.")
                qs = urlencode({'linea': linea, 'jornada': jornada, 'grado': grado_filtro})
                return redirect(f"{request.path}?{qs}")

            else:
                # Una casilla en blanco significa "sin calificar todavía": se ignora y NO borra
                # una nota que ya existiera. Solo se guarda cuando el docente escribe un valor.
                # Para borrar una nota puntual hay que marcar explícitamente su casilla
                # "borrar_<estudiante>_<actividad>" (el botón 🗑 de la interfaz).
                borrados = 0
                for est in estudiantes_grupo:
                    for act in actividades:
                        campo = f'nota_{est.id}_{act.id}'
                        campo_borrar = f'borrar_{est.id}_{act.id}'
                        if request.POST.get(campo_borrar):
                            eliminadas, _ = NotaActividad.objects.filter(estudiante=est, actividad=act).delete()
                            if eliminadas:
                                borrados += 1
                            continue
                        valor_txt = request.POST.get(campo, '').strip().replace(',', '.')
                        if valor_txt == '':
                            continue
                        try:
                            valor = Decimal(valor_txt)
                        except InvalidOperation:
                            continue
                        valor = max(Decimal('0.0'), min(Decimal('5.0'), valor)).quantize(Decimal('0.01'))
                        NotaActividad.objects.update_or_create(
                            estudiante=est, actividad=act,
                            defaults={'valor': valor, 'registrado_por': request.user},
                        )
                if borrados:
                    messages.success(request, f"Notas guardadas ({borrados} eliminada{'s' if borrados != 1 else ''}).")
                else:
                    messages.success(request, "Notas guardadas.")
                qs = urlencode({'linea': linea, 'jornada': jornada, 'grado': grado_filtro})
                return redirect(f"{request.path}?{qs}")

        notas_qs = NotaActividad.objects.filter(estudiante__in=estudiantes_grupo, actividad__in=actividades)
        for n in notas_qs:
            notas_grid.setdefault(n.estudiante_id, {})[n.actividad_id] = n.valor

        registros_puntos = RegistroPlanilla.objects.filter(estudiante__in=estudiantes_grupo).values(
            'estudiante_id', 'fecha', 'bloque', 'estado'
        )
        puntos_por_estudiante = RegistroPlanilla.calcular_puntos_por_estudiante(registros_puntos)

        for est in estudiantes_grupo:
            notas_est = list(notas_grid.get(est.id, {}).values())
            promedio = (sum(notas_est) / len(notas_est)) if notas_est else None
            puntos = puntos_por_estudiante.get(est.id, 0)
            definitiva = (promedio + Decimal(puntos)) if promedio is not None else None
            resumen[est.id] = {'promedio': promedio, 'puntos': puntos, 'definitiva': definitiva}

    return render(request, 'estudiantes/notas.html', {
        'es_directivo':       es_directivo,
        'grupos_disponibles': grupos_disponibles,
        'grados_disponibles': grados_disponibles,
        'linea': linea, 'jornada': jornada, 'grado_filtro': grado_filtro,
        'linea_display':   dict(Estudiante.LINEA_MEDIA).get(linea, linea),
        'jornada_display': dict(Estudiante.JORNADA).get(jornada, jornada),
        'estudiantes_grupo': estudiantes_grupo,
        'actividades': actividades,
        'notas_grid': notas_grid,
        'resumen': resumen,
    })


@login_required
@bloquear_estudiantes
def historial_planilla(request):
    """Permite ver, ajustar y borrar registros ya guardados de la planilla (llegadas tarde,
    fallas, etc.) sin tener que ubicar la fecha exacta en la planilla del día."""
    if not _puede_usar_planilla(request.user):
        messages.error(request, "Su cuenta no tiene una línea asignada.")
        return redirect('inicio')

    es_directivo, linea, jornada, grado_filtro, grupos_disponibles, grados_disponibles, estudiantes_grupo = _resolver_grupo(request)

    if request.method == 'POST':
        reg_id = request.POST.get('registro_id')
        registro = RegistroPlanilla.objects.filter(id=reg_id, estudiante__in=estudiantes_grupo).first()

        if registro and 'eliminar' in request.POST:
            registro.delete()
            messages.success(request, "Registro eliminado.")

        elif registro and 'ajustar' in request.POST:
            nuevo_estado = request.POST.get('nuevo_estado', '')
            if nuevo_estado not in dict(RegistroPlanilla.ESTADOS):
                messages.error(request, "Estado no válido.")
            elif RegistroPlanilla.objects.filter(
                estudiante=registro.estudiante, fecha=registro.fecha, bloque=registro.bloque, estado=nuevo_estado
            ).exclude(id=registro.id).exists():
                messages.error(request, "Ese estudiante ya tiene ese ítem registrado en ese mismo bloque.")
            else:
                registro.estado = nuevo_estado
                registro.registrado_por = request.user
                registro.save()
                messages.success(request, "Registro ajustado.")
        else:
            messages.error(request, "No se encontró el registro o no pertenece a su grupo.")

        qs = urlencode({'linea': linea, 'jornada': jornada, 'grado': grado_filtro, 'q': request.POST.get('q', ''), 'page': request.POST.get('page', '')})
        return redirect(f"{request.path}?{qs}")

    busqueda = request.GET.get('q', '').strip()
    registros_qs = RegistroPlanilla.objects.filter(estudiante__in=estudiantes_grupo).select_related('estudiante', 'registrado_por')
    if busqueda:
        registros_qs = registros_qs.filter(
            Q(estudiante__nombres__icontains=busqueda)
            | Q(estudiante__apellidos__icontains=busqueda)
            | Q(estudiante__documento__icontains=busqueda)
        )
    registros_qs = registros_qs.order_by('-fecha', '-bloque', 'estudiante__apellidos')

    paginator = Paginator(registros_qs, 50)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    return render(request, 'estudiantes/historial_planilla.html', {
        'es_directivo':       es_directivo,
        'grupos_disponibles': grupos_disponibles,
        'grados_disponibles': grados_disponibles,
        'linea': linea, 'jornada': jornada, 'grado_filtro': grado_filtro,
        'linea_display':   dict(Estudiante.LINEA_MEDIA).get(linea, linea),
        'jornada_display': dict(Estudiante.JORNADA).get(jornada, jornada),
        'busqueda': busqueda,
        'page_obj': page_obj,
        'estados': RegistroPlanilla.ESTADOS,
    })


@login_required
@bloquear_estudiantes
def exportar_planilla(request):
    if not _puede_usar_planilla(request.user):
        messages.error(request, "Su cuenta no tiene una línea asignada.")
        return redirect('inicio')

    es_directivo, linea, jornada, grado_filtro, grupos_disponibles, grados_disponibles, estudiantes_grupo = _resolver_grupo(request)
    if not (linea and jornada):
        messages.error(request, "Seleccione una línea y una jornada antes de exportar.")
        return redirect('planilla')

    estudiantes_grupo = list(estudiantes_grupo)
    actividades = list(Actividad.objects.filter(linea=linea, jornada=jornada))

    registros = (
        RegistroPlanilla.objects.filter(estudiante__in=estudiantes_grupo)
        .select_related('estudiante', 'registrado_por')
        .order_by('fecha', 'bloque', 'estudiante__curso', 'estudiante__apellidos')
    )
    notas_qs = NotaActividad.objects.filter(estudiante__in=estudiantes_grupo, actividad__in=actividades)

    conteos = {}
    for r in registros:
        conteos.setdefault(r.estudiante_id, {})
        conteos[r.estudiante_id][r.estado] = conteos[r.estudiante_id].get(r.estado, 0) + 1

    puntos_por_estudiante = RegistroPlanilla.calcular_puntos_por_estudiante(registros)

    notas_grid = {}
    for n in notas_qs:
        notas_grid.setdefault(n.estudiante_id, {})[n.actividad_id] = float(n.valor)

    hf = PatternFill("solid", fgColor="1a3a6e")
    hfont = Font(color="FFFFFF", bold=True, size=11)
    halign = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin = Side(style="thin", color="D1D5DB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    alt = PatternFill("solid", fgColor="F8FAFC")

    COLORES_ESTADO = {
        'F':  PatternFill("solid", fgColor="FF0000"),
        'A':  PatternFill("solid", fgColor="FFFF00"),
        'R':  PatternFill("solid", fgColor="FF9900"),
        'E':  PatternFill("solid", fgColor="7030A0"),
        'EX': PatternFill("solid", fgColor="92D050"),
        'U':  PatternFill("solid", fgColor="002060"),
    }
    FUENTE_ESTADO = {
        'F':  Font(color="FFFFFF", bold=True),
        'A':  Font(color="333333", bold=True),
        'R':  Font(color="C00000", bold=True),
        'E':  Font(color="FFFF00", bold=True),
        'EX': Font(color="333333", bold=True),
        'U':  Font(color="FFFF00", bold=True),
    }

    wb = openpyxl.Workbook()

    # ── Hoja 1: Resumen (asistencia + notas + definitiva) ───
    ws1 = wb.active
    ws1.title = "Resumen"
    encabezados = ['Curso', 'Apellidos', 'Nombres', 'Documento',
                    'F', 'A', 'R', 'E', 'EX', 'U', 'Puntos asistencia',
                    'Promedio notas', 'Definitiva']
    for ci, h in enumerate(encabezados, 1):
        c = ws1.cell(row=1, column=ci, value=h)
        c.fill = hf; c.font = hfont; c.alignment = halign; c.border = border
    ws1.row_dimensions[1].height = 26

    fila = 2
    for est in estudiantes_grupo:
        cdatos = conteos.get(est.id, {})
        puntos = float(puntos_por_estudiante.get(est.id, 0))
        notas_est = list(notas_grid.get(est.id, {}).values())
        promedio = (sum(notas_est) / len(notas_est)) if notas_est else None
        definitiva = (promedio + puntos) if promedio is not None else None

        valores = [
            est.curso, est.apellidos, est.nombres, est.documento,
            cdatos.get('F', 0), cdatos.get('A', 0), cdatos.get('R', 0),
            cdatos.get('E', 0), cdatos.get('EX', 0), cdatos.get('U', 0),
            puntos,
            round(promedio, 2) if promedio is not None else '',
            round(definitiva, 2) if definitiva is not None else '',
        ]
        for ci, v in enumerate(valores, 1):
            c = ws1.cell(row=fila, column=ci, value=v)
            c.border = border
            c.alignment = Alignment(vertical="center", horizontal="left" if ci <= 3 else "center")
            if fila % 2 == 0:
                c.fill = alt
        fila += 1

    for i, w in enumerate([10, 20, 20, 14, 6, 6, 6, 6, 6, 6, 16, 14, 12], 1):
        ws1.column_dimensions[get_column_letter(i)].width = w
    ws1.freeze_panes = "A2"

    # ── Hoja 2: Detalle de asistencia (reporte de fallas y descuentos) ───
    ws2 = wb.create_sheet("Detalle asistencia")
    enc2 = ['Fecha', 'Bloque', 'Curso', 'Apellidos', 'Nombres', 'Documento', 'Estado', 'Puntos', 'Registrado por']
    for ci, h in enumerate(enc2, 1):
        c = ws2.cell(row=1, column=ci, value=h)
        c.fill = hf; c.font = hfont; c.alignment = halign; c.border = border
    ws2.row_dimensions[1].height = 26

    fila = 2
    for r in registros:
        est = r.estudiante
        valores = [
            r.fecha.strftime('%d/%m/%Y'), f"Bloque {r.bloque}", est.curso, est.apellidos, est.nombres, est.documento,
            dict(RegistroPlanilla.ESTADOS).get(r.estado, r.estado), r.puntos,
            (r.registrado_por.get_full_name() or r.registrado_por.username) if r.registrado_por else '',
        ]
        for ci, v in enumerate(valores, 1):
            c = ws2.cell(row=fila, column=ci, value=v)
            c.border = border
            c.alignment = Alignment(vertical="center", horizontal="left" if ci in (3, 4, 5) else "center")
            if ci == 7:
                c.fill = COLORES_ESTADO.get(r.estado, PatternFill())
                c.font = FUENTE_ESTADO.get(r.estado, Font())
        fila += 1

    for i, w in enumerate([12, 10, 10, 20, 20, 14, 18, 8, 22], 1):
        ws2.column_dimensions[get_column_letter(i)].width = w
    ws2.freeze_panes = "A2"

    # ── Hoja 3: Notas por actividad ───
    if actividades:
        ws3 = wb.create_sheet("Notas por actividad")
        enc3 = ['Curso', 'Apellidos', 'Nombres', 'Documento'] + [a.nombre for a in actividades] + ['Promedio']
        for ci, h in enumerate(enc3, 1):
            c = ws3.cell(row=1, column=ci, value=h)
            c.fill = hf; c.font = hfont; c.alignment = halign; c.border = border
        ws3.row_dimensions[1].height = 26

        fila = 2
        for est in estudiantes_grupo:
            notas_est_dict = notas_grid.get(est.id, {})
            valores = [est.curso, est.apellidos, est.nombres, est.documento]
            for a in actividades:
                valores.append(notas_est_dict.get(a.id, ''))
            notas_vals = list(notas_est_dict.values())
            promedio = round(sum(notas_vals) / len(notas_vals), 2) if notas_vals else ''
            valores.append(promedio)
            for ci, v in enumerate(valores, 1):
                c = ws3.cell(row=fila, column=ci, value=v)
                c.border = border
                c.alignment = Alignment(vertical="center", horizontal="left" if ci <= 3 else "center")
                if fila % 2 == 0:
                    c.fill = alt
            fila += 1

        anchos3 = [10, 20, 20, 14] + [16] * len(actividades) + [12]
        for i, w in enumerate(anchos3, 1):
            ws3.column_dimensions[get_column_letter(i)].width = w
        ws3.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    partes_nombre = [linea, jornada] + ([f"{grado_filtro}"] if grado_filtro else [])
    nombre_archivo = "planilla_" + "_".join(partes_nombre) + ".xlsx"
    resp = HttpResponse(
        buf.getvalue(),
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    resp['Content-Disposition'] = f'attachment; filename="{nombre_archivo}"'
    return resp


# ── Almuerzo ─────────────────────────────────────────────────

BLOQUEO_SEGUNDOS = 5

TIPOS_ESCANER = {
    'ALM': {'label': 'Registro de Almuerzo',  'icono': '\U0001f37d\ufe0f', 'color': '#e63946'},
    'TAR': {'label': 'Llegada Tarde',          'icono': '\u23f0',            'color': '#f4a261'},
    'UNI': {'label': 'Porte de Uniforme',      'icono': '\U0001f454',        'color': '#2a9d8f'},
    'ASI': {'label': 'Asistencia a Clase',     'icono': '\U0001f4cb',        'color': '#457b9d'},
}

@login_required
@bloquear_estudiantes
def escaner(request):
    tipo_actual = request.GET.get('tipo', 'ALM')
    if tipo_actual not in TIPOS_ESCANER:
        tipo_actual = 'ALM'

    mensaje = contador = nombre = None

    if request.method == 'POST':
        documento   = request.POST.get('documento', '').strip()
        tipo_actual = request.POST.get('tipo', tipo_actual)
        if tipo_actual not in TIPOS_ESCANER:
            tipo_actual = 'ALM'

        try:
            est    = Estudiante.objects.get(documento=documento)
            ahora  = timezone.now()
            limite = ahora - timedelta(seconds=BLOQUEO_SEGUNDOS)
            ultimo = Asistencia.objects.filter(estudiante=est, tipo=tipo_actual).order_by('-fecha', '-hora').first()
            if ultimo:
                fhu = timezone.make_aware(timezone.datetime.combine(ultimo.fecha, ultimo.hora))
                if fhu > limite:
                    mensaje = f"Espere {BLOQUEO_SEGUNDOS} segundos antes de volver a escanear"
                else:
                    Asistencia.objects.create(estudiante=est, tipo=tipo_actual)
            else:
                Asistencia.objects.create(estudiante=est, tipo=tipo_actual)
            hoy      = timezone.localdate()
            contador = Asistencia.objects.filter(estudiante=est, fecha=hoy, tipo=tipo_actual).count()
            nombre   = f"{est.nombres} {est.apellidos}"
        except Estudiante.DoesNotExist:
            mensaje = "Documento no encontrado"

    info = TIPOS_ESCANER[tipo_actual]
    return render(request, 'estudiantes/escaner.html', {
        'mensaje':     mensaje,
        'contador':    contador,
        'nombre':      nombre,
        'tipo_actual': tipo_actual,
        'tipos':       TIPOS_ESCANER,
        'info':        info,
    })


# Redirige la URL antigua para no romper bookmarks
@login_required
@bloquear_estudiantes
def almuerzo(request):
    from django.shortcuts import redirect as _redirect
    return _redirect('/estudiantes/escaner/?tipo=ALM')


# ── Escáner AJAX — responde JSON, sin recargar la página ─────────────────────
@login_required
@bloquear_estudiantes
def escaner_registrar(request):
    if request.method != 'POST':
        return JsonResponse({'ok': False, 'mensaje': 'Método no permitido'}, status=405)

    documento   = request.POST.get('documento', '').strip()
    tipo_actual = request.POST.get('tipo', 'ALM')
    if tipo_actual not in TIPOS_ESCANER:
        tipo_actual = 'ALM'

    if not documento:
        return JsonResponse({'ok': False, 'mensaje': 'Documento vacío'})

    try:
        est    = Estudiante.objects.get(documento=documento)
        ahora  = timezone.now()
        limite = ahora - timedelta(seconds=BLOQUEO_SEGUNDOS)
        ultimo = Asistencia.objects.filter(
            estudiante=est, tipo=tipo_actual
        ).order_by('-fecha', '-hora').first()

        if ultimo:
            fhu = timezone.make_aware(
                timezone.datetime.combine(ultimo.fecha, ultimo.hora)
            )
            if fhu > limite:
                return JsonResponse({
                    'ok': False,
                    'tipo': 'espera',
                    'mensaje': f'Espere {BLOQUEO_SEGUNDOS} segundos antes de volver a escanear',
                    'nombre': f'{est.nombres} {est.apellidos}',
                })

        Asistencia.objects.create(estudiante=est, tipo=tipo_actual)
        hoy      = timezone.localdate()
        contador = Asistencia.objects.filter(
            estudiante=est, fecha=hoy, tipo=tipo_actual
        ).count()

        return JsonResponse({
            'ok':       True,
            'nombre':   f'{est.nombres} {est.apellidos}',
            'contador': contador,
            'label':    TIPOS_ESCANER[tipo_actual]['label'],
        })

    except Estudiante.DoesNotExist:
        return JsonResponse({'ok': False, 'mensaje': 'Documento no encontrado'})


def exit(request):
    logout(request)
    return redirect('inicio')


# ── Gestión masiva (solo directivos) ─────────────────────────

@login_required
@solo_directivo
def gestion_masiva(request):
    cursos_disponibles = Estudiante.objects.values_list('curso', flat=True).distinct().order_by('curso')
    return render(request, 'estudiantes/gestion_masiva.html', {
        'total':              Estudiante.objects.count(),
        'campos':             CAMPOS_EXPORTAR,
        'jornadas':           Estudiante.JORNADA,
        'lineas':             Estudiante.LINEA_MEDIA,
        'cursos_disponibles': cursos_disponibles,
    })


@login_required
@solo_directivo
def exportar_estudiantes(request):
    qs  = _qs_filtrada(request.GET)
    buf = _build_excel(qs)
    response = HttpResponse(buf.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=estudiantes.xlsx'
    return response


@login_required
@solo_directivo
def importar_estudiantes(request):
    if request.method == 'POST':
        if request.POST.get('confirm') == '1':
            filas = json.loads(request.POST.get('filas_json', '[]'))
            creados = actualizados = omitidos = 0
            for fila in filas:
                if fila.get('error'): omitidos += 1; continue
                doc = fila.get('documento', '').strip()
                if not doc: omitidos += 1; continue
                campos = {k: v for k, v in fila.items()
                          if k not in ('error', 'errores', 'advertencias', 'fila', 'existe', 'documento', 'archivo_foto')}
                archivo_foto = fila.get('archivo_foto', '').strip()
                if archivo_foto:
                    ruta_foto = os.path.join(settings.MEDIA_ROOT, 'fotos', archivo_foto)
                    if os.path.isfile(ruta_foto):
                        campos['foto'] = f'fotos/{archivo_foto}'
                _, creado = Estudiante.objects.update_or_create(documento=doc, defaults=campos)
                creados += 1 if creado else 0
                actualizados += 0 if creado else 1
            messages.success(request, f"Importación: {creados} creados, {actualizados} actualizados, {omitidos} omitidos.")
            return redirect('gestion_masiva')

        archivo = request.FILES.get('archivo')
        if not archivo:
            messages.error(request, "Seleccione un archivo Excel.")
            return redirect('gestion_masiva')
        filas, errores = _leer_excel(archivo)
        if errores:
            for e in errores: messages.error(request, e)
            return redirect('gestion_masiva')

        preview = []
        for i, fila in enumerate(filas, 1):
            row = dict(fila)
            errores = []
            for campo in CAMPOS_IMPORTAR_REQUERIDOS:
                if not row.get(campo, '').strip():
                    errores.append(f"'{campo}' es requerido")
            if row.get('jornada') and row['jornada'] not in VALORES_JORNADA:
                errores.append(f"Jornada '{row['jornada']}' inválida")
            if row.get('linea') and row['linea'] not in VALORES_LINEA:
                errores.append(f"Línea '{row['linea']}' inválida")
            advertencias = []
            archivo_foto = row.get('archivo_foto', '').strip()
            if archivo_foto:
                ruta_foto = os.path.join(settings.MEDIA_ROOT, 'fotos', archivo_foto)
                if not os.path.isfile(ruta_foto):
                    advertencias.append(f"Foto '{archivo_foto}' no encontrada en la carpeta de fotos")
            doc = row.get('documento', '').strip()
            row['fila']    = i
            row['errores'] = errores
            row['advertencias'] = advertencias
            row['error']   = bool(errores)
            row['existe']  = Estudiante.objects.filter(documento=doc).exists() if doc else False
            preview.append(row)

        validos   = sum(1 for r in preview if not r['error'])
        invalidos = sum(1 for r in preview if r['error'])
        return render(request, 'estudiantes/importar_preview.html', {
            'preview': preview, 'validos': validos, 'invalidos': invalidos,
            'filas_json': json.dumps(preview),
        })
    return redirect('gestion_masiva')


@login_required
@solo_directivo
def editar_masivo(request):
    if request.method != 'POST':
        return redirect('gestion_masiva')
    jornada = request.POST.get('filtro_jornada', '')
    curso   = request.POST.get('filtro_curso', '')
    linea   = request.POST.get('filtro_linea', '')
    if not (jornada or curso or linea):
        messages.error(request, "Defina al menos un filtro.")
        return redirect('gestion_masiva')
    qs = Estudiante.objects.all()
    if jornada: qs = qs.filter(jornada=jornada)
    if curso:   qs = qs.filter(curso__iexact=curso)
    if linea:   qs = qs.filter(linea=linea)
    if not qs.exists():
        messages.warning(request, "No se encontraron estudiantes con esos filtros.")
        return redirect('gestion_masiva')
    cambios = {}
    nj = request.POST.get('nuevo_jornada', '').strip()
    nc = request.POST.get('nuevo_curso', '').strip()
    nl = request.POST.get('nuevo_linea', '').strip()
    if nj and nj in VALORES_JORNADA: cambios['jornada'] = nj
    if nc: cambios['curso'] = nc
    if nl and nl in VALORES_LINEA:   cambios['linea']   = nl
    if not cambios:
        messages.warning(request, "No se indicaron campos a cambiar.")
        return redirect('gestion_masiva')
    total = qs.count()
    qs.update(**cambios)
    messages.success(request, f"Se actualizaron {total} estudiantes.")
    return redirect('gestion_masiva')


# ── Gestión de usuarios (solo directivos) ───────────────────

@login_required
@solo_directivo
def lista_usuarios(request):
    usuarios = User.objects.exclude(is_superuser=True).select_related().prefetch_related('groups').order_by('last_name', 'first_name')
    return render(request, 'usuarios/lista.html', {
        'usuarios': usuarios,
        'es_directivo': True,
    })


@login_required
@solo_directivo
def crear_usuario(request):
    _asegurar_grupos()
    if request.method == 'POST':
        form = UsuarioCrearForm(request.POST)
        if form.is_valid():
            password_plano = form.cleaned_data['password1']
            rol = form.cleaned_data['rol']
            user = form.save(commit=False)
            user.is_staff = False
            user.save()

            # Asignar grupo
            grupo, _ = Group.objects.get_or_create(name=rol)
            user.groups.set([grupo])

            # Grupo (línea/jornada/curso) asignado para la planilla, si es docente
            if rol == 'docente':
                DocentePerfil.objects.update_or_create(
                    usuario=user,
                    defaults={
                        'linea': form.cleaned_data['grupo_linea'],
                        'jornada': form.cleaned_data['grupo_jornada'],
                    },
                )
            else:
                DocentePerfil.objects.filter(usuario=user).delete()

            # Enviar correo de bienvenida
            resultado = _enviar_bienvenida(user, password_plano, rol)
            if resultado is True:
                messages.success(request, f"Usuario '{user.username}' creado. Se envió correo de bienvenida a {user.email}.")
            else:
                messages.warning(request, f"Usuario creado, pero no se pudo enviar el correo: {resultado}")

            return redirect('lista_usuarios')
    else:
        form = UsuarioCrearForm()

    return render(request, 'usuarios/form_usuario.html', {
        'form':  form,
        'titulo': 'Crear usuario',
        'es_nuevo': True,
    })


@login_required
@solo_directivo
def editar_usuario(request, id):
    _asegurar_grupos()
    usuario = get_object_or_404(User, id=id)
    if request.method == 'POST':
        form = UsuarioEditarForm(request.POST, instance=usuario)
        if form.is_valid():
            rol = form.cleaned_data['rol']
            user = form.save()
            grupo, _ = Group.objects.get_or_create(name=rol)
            user.groups.set([grupo])
            if rol == 'docente':
                DocentePerfil.objects.update_or_create(
                    usuario=user,
                    defaults={
                        'linea': form.cleaned_data['grupo_linea'],
                        'jornada': form.cleaned_data['grupo_jornada'],
                    },
                )
            else:
                DocentePerfil.objects.filter(usuario=user).delete()
            messages.success(request, f"Usuario '{user.username}' actualizado.")
            return redirect('lista_usuarios')
    else:
        form = UsuarioEditarForm(instance=usuario)

    return render(request, 'usuarios/form_usuario.html', {
        'form':    form,
        'titulo':  f'Editar usuario: {usuario.get_full_name() or usuario.username}',
        'usuario': usuario,
        'es_nuevo': False,
    })


@login_required
@solo_directivo
def eliminar_usuario(request, id):
    usuario = get_object_or_404(User, id=id)
    if usuario == request.user:
        messages.error(request, "No puede eliminar su propia cuenta.")
        return redirect('lista_usuarios')
    nombre = usuario.get_full_name() or usuario.username
    usuario.delete()
    messages.success(request, f"Usuario '{nombre}' eliminado.")
    return redirect('lista_usuarios')
