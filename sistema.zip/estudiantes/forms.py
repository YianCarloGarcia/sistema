from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Estudiante


class EstudianteForm(forms.ModelForm):
    class Meta:
        model  = Estudiante
        fields = '__all__'
        widgets = {
            'jornada':  forms.Select(attrs={'class': 'form-select'}),
            'tipo':     forms.Select(attrs={'class': 'form-select'}),
            'linea':    forms.Select(attrs={'class': 'form-select'}),
            'documento':           forms.TextInput(attrs={'class': 'form-control'}),
            'apellidos':           forms.TextInput(attrs={'class': 'form-control'}),
            'nombres':             forms.TextInput(attrs={'class': 'form-control'}),
            'curso':               forms.TextInput(attrs={'class': 'form-control'}),
            'grado':               forms.Select(attrs={'class': 'form-select'}),
            'celular':             forms.TextInput(attrs={'class': 'form-control'}),
            'email':               forms.EmailInput(attrs={'class': 'form-control'}),
            'acudiente':           forms.TextInput(attrs={'class': 'form-control'}),
            'parentesco':          forms.TextInput(attrs={'class': 'form-control'}),
            'tel_acudiente':       forms.TextInput(attrs={'class': 'form-control'}),
            'tel2_acudiente':      forms.TextInput(attrs={'class': 'form-control'}),
            'direccion':           forms.TextInput(attrs={'class': 'form-control'}),
            'ocupacion_acudiente': forms.TextInput(attrs={'class': 'form-control'}),
            'eps':                 forms.TextInput(attrs={'class': 'form-control'}),
            'observaciones':       forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'foto':                forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'en_practica':           forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'fecha_inicio_practica': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'dependencia_practica':  forms.Select(attrs={'class': 'form-select'}),
        }


ROL_CHOICES = [
    ('docente',   'Docente — puede ver y buscar, no editar'),
    ('directivo', 'Directivo — acceso completo'),
    ('estudiante', 'Estudiante — solo consulta su propio historial y progreso'),
]


class UsuarioCrearForm(UserCreationForm):
    """Formulario para crear usuarios con rol y correo."""
    first_name = forms.CharField(
        label='Nombres', max_length=60,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
    )
    last_name = forms.CharField(
        label='Apellidos', max_length=60,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
    )
    email = forms.EmailField(
        label='Correo electrónico', required=False,
        widget=forms.EmailInput(attrs={'class': 'form-control'}),
        help_text='Se enviará un correo de bienvenida con las credenciales.',
    )
    estudiante_documento = forms.CharField(
        label='Documento del estudiante', max_length=30, required=False,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        help_text='Documento de una ficha de estudiante existente que aún no tenga cuenta.',
    )
    rol = forms.ChoiceField(
        label='Rol', choices=ROL_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'}),
    )
    grupo_linea = forms.ChoiceField(
        label='Línea asignada', choices=[('', '— Selecciona —')] + Estudiante.LINEA_MEDIA,
        required=False, widget=forms.Select(attrs={'class': 'form-select'}),
    )
    grupo_jornada = forms.ChoiceField(
        label='Jornada asignada', choices=[('', '— Selecciona —')] + Estudiante.JORNADA,
        required=False, widget=forms.Select(attrs={'class': 'form-select'}),
    )

    class Meta:
        model  = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs['class'] = 'form-control'
        self.fields['password2'].widget.attrs['class'] = 'form-control'
        self.fields['username'].help_text = 'Solo letras, números y @/./+/-/_'

    def clean(self):
        cleaned = super().clean()
        rol = cleaned.get('rol')
        if rol == 'docente':
            faltantes = [f for f in ('grupo_linea', 'grupo_jornada') if not cleaned.get(f)]
            if faltantes:
                raise forms.ValidationError('Para un docente debe indicar la línea y la jornada que va a manejar en la planilla.')
        if rol != 'estudiante' and not cleaned.get('email'):
            self.add_error('email', 'Este campo es obligatorio.')
        if rol == 'estudiante':
            documento = (cleaned.get('estudiante_documento') or '').strip()
            ficha = Estudiante.objects.filter(documento=documento).first() if documento else None
            if ficha is None:
                raise forms.ValidationError('Indique el documento de una ficha de estudiante existente.')
            if ficha.usuario_id:
                raise forms.ValidationError('Ese estudiante ya tiene una cuenta de acceso.')
            cleaned['estudiante_obj'] = ficha
        return cleaned


class UsuarioEditarForm(forms.ModelForm):
    """Formulario para editar usuario existente (sin cambiar contraseña aquí)."""
    rol = forms.ChoiceField(
        label='Rol', choices=ROL_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'}),
    )
    grupo_linea = forms.ChoiceField(
        label='Línea asignada', choices=[('', '— Selecciona —')] + Estudiante.LINEA_MEDIA,
        required=False, widget=forms.Select(attrs={'class': 'form-select'}),
    )
    grupo_jornada = forms.ChoiceField(
        label='Jornada asignada', choices=[('', '— Selecciona —')] + Estudiante.JORNADA,
        required=False, widget=forms.Select(attrs={'class': 'form-select'}),
    )

    class Meta:
        model  = User
        fields = ('username', 'first_name', 'last_name', 'email', 'is_active')
        widgets = {
            'username':   forms.TextInput(attrs={'class': 'form-control'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name':  forms.TextInput(attrs={'class': 'form-control'}),
            'email':      forms.EmailInput(attrs={'class': 'form-control'}),
            'is_active':  forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

    def __init__(self, *args, **kwargs):
        # Precarga el rol desde los grupos del usuario
        instance = kwargs.get('instance')
        initial  = kwargs.get('initial', {})
        if instance:
            grupos = list(instance.groups.values_list('name', flat=True))
            if hasattr(instance, 'estudiante_perfil'):
                initial['rol'] = 'estudiante'
            elif 'directivo' in grupos:
                initial['rol'] = 'directivo'
            else:
                initial['rol'] = 'docente'
            perfil = getattr(instance, 'docente_perfil', None)
            if perfil:
                initial['grupo_linea'] = perfil.linea
                initial['grupo_jornada'] = perfil.jornada
        kwargs['initial'] = initial
        super().__init__(*args, **kwargs)

    def clean(self):
        cleaned = super().clean()
        rol = cleaned.get('rol')
        es_cuenta_estudiante = bool(self.instance.pk and hasattr(self.instance, 'estudiante_perfil'))
        if rol == 'docente':
            faltantes = [f for f in ('grupo_linea', 'grupo_jornada') if not cleaned.get(f)]
            if faltantes:
                raise forms.ValidationError('Para un docente debe indicar la línea y la jornada que va a manejar en la planilla.')
        if es_cuenta_estudiante and rol != 'estudiante':
            raise forms.ValidationError('Esta cuenta pertenece a un estudiante; su rol no se puede cambiar.')
        if rol == 'estudiante' and not es_cuenta_estudiante:
            raise forms.ValidationError('Para una cuenta de estudiante use «Crear usuario» y elija su ficha.')
        return cleaned
